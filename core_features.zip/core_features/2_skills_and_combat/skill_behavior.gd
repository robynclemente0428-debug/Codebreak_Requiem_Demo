class_name SkillBehavior
extends RefCounted

const BARRIER_SECONDS := 4.0
const GUARD_MIN_SECONDS := 0.6
const GUARD_MAX_SECONDS := 2.0


func execute(caster: Node3D, skill: SkillInstance, stats: StatComponent) -> void:
	var cast := SkillCast.new(caster, skill, stats, self)
	var delay := _play_animation(cast)
	if delay > 0.0:
		await caster.get_tree().create_timer(delay).timeout
		if not cast.is_valid() or is_dead(cast.caster):
			return
	if is_dead(caster):
		return
	for s in skill.support_behaviors:
		s.before_release(cast)
	_apply_defense(cast)
	release(cast)


func _apply_defense(cast: SkillCast) -> void:
	if cast.depth > 0 or cast.extra.get("hologram", false):
		return
	var hp := cast.caster.get("health") as HealthComponent
	if hp == null:
		return
	var barrier := cast.flag("barrier")
	if barrier > 0.0 and hp.stats != null:
		hp.add_barrier(barrier * hp.stats.get_stat(StatTypes.Stat.MAX_HEALTH), BARRIER_SECONDS)
	var guard := cast.flag("guard")
	if guard > 0.0:
		hp.add_guard(guard, clampf(recovery_time(cast), GUARD_MIN_SECONDS, GUARD_MAX_SECONDS))


static func is_dead(node: Node) -> bool:
	if not is_instance_valid(node):
		return true
	var h = node.get("health")
	return h is HealthComponent and h.current_health <= 0.0


func release(_cast: SkillCast) -> void:
	push_error("%s: release() not implemented" % get_script().resource_path)


func repeat_release(cast: SkillCast, _from_impact: Variant, _direction: Vector3) -> void:
	release(cast)


func aim_preview(_caster: Node3D, _skill: SkillInstance) -> Array:
	return []


func waits_for_impact() -> bool:
	return false


func recovery_time(cast: SkillCast) -> float:
	var recovery := maxf(cast.flag("recovery_mult"), 1.0)
	return recovery / maxf(cast.stats.get_stat(StatTypes.Stat.ATTACK_SPEED) * cast.skill.speed_mult(), 0.1)


func _play_animation(cast: SkillCast) -> float:
	var caster := cast.caster
	if not caster.has_method("play_skill_animation"):
		return 0.0
	var cooldown := recovery_time(cast)
	var key := cast.skill.peek_animation_key(cooldown + cast.flag("combo_grace"))
	var delay: float = caster.play_skill_animation(key, cooldown)
	if delay > 0.0:
		cast.skill.advance_animation()
	return delay


func hit(cast: SkillCast, target: Node, damage_mult := 1.0) -> HitInfo:
	var info := HitInfo.new()
	info.cast = cast
	info.target = target
	if not cast.is_valid() or not is_instance_valid(target):
		return info
	if cast.caster.get("is_remote") == true:
		return info
	var target_health := target.get("health") as HealthComponent
	if target_health == null:
		return info
	if target is Node3D:
		info.position = (target as Node3D).global_position
	info.damage = cast.skill.roll_damage(cast.stats) * damage_mult * cast.damage_mult
	if cast.skill.class_trait != null:
		info.damage *= cast.skill.class_trait.hit_damage_mult(cast.caster, target)
	info.is_crit = cast.skill.last_roll_was_crit

	for s in cast.skill.support_behaviors:
		s.modify_hit(cast, target, info)
	if info.cancelled:
		return info
	var traits: Array = target.get("traits") if "traits" in target else []
	var on_copy: bool = target.get("is_remote") == true and target is EnemyBase
	if not traits.is_empty() or on_copy:
		info.facts = HitFacts.from_cast(cast)
	if on_copy:
		Coop.hit_facts = info.facts
		traits = []
	for t: EnemyTrait in traits:
		t.modify_incoming(info)
	if info.cancelled:
		return info
	if info.absorbed:
		if target_health.current_health <= 0.0:
			return info
		info.landed = true
		cast.already_hit.append(target)
		for t: EnemyTrait in traits:
			if is_instance_valid(t):
				t.after_hit(info)
		for s in cast.skill.support_behaviors:
			s.on_hit(cast, target, info)
		return info
	var own: Array = cast.caster.get("traits") if "traits" in cast.caster else []
	for t: EnemyTrait in own:
		if is_instance_valid(t):
			t.on_outgoing(info)

	Coop.hit_source = Coop.Hit.PLAYER if cast.caster is Player else Coop.Hit.ENEMY
	Coop.damage_by = Coop.my_id() if cast.caster is Player and Coop.in_game else 0
	info.dealt = target_health.take_damage(info.damage)
	Coop.damage_by = 0
	Coop.hit_source = Coop.Hit.NONE
	Coop.hit_facts = null
	if info.dealt <= 0.0:
		return info
	info.landed = true
	info.killed = target_health.current_health <= 0.0
	Coop.my_hit(target, cast, info)
	cast.already_hit.append(target)
	for t: EnemyTrait in traits:
		if is_instance_valid(t):
			t.after_hit(info)

	if not target.is_in_group(&"breakables") and not on_copy:
		landing_rewards(cast, info)

	for s in cast.skill.support_behaviors:
		s.on_hit(cast, target, info)
		if info.killed:
			s.on_kill(cast, target, info)
	return info


func landing_rewards(cast: SkillCast, info: HitInfo) -> void:
	if not cast.is_valid():
		return
	_apply_on_hit_stats(cast)
	var leech := cast.flag("leech") + info.leech_bonus
	var caster_hp := cast.caster.get("health") as HealthComponent
	if leech > 0.0 and caster_hp != null:
		caster_hp.heal(info.dealt * leech)
	if caster_hp != null:
		if info.barrier_bonus > 0.0 and caster_hp.stats != null:
			caster_hp.add_barrier(info.barrier_bonus * caster_hp.stats.get_stat(StatTypes.Stat.MAX_HEALTH), BARRIER_SECONDS)
		if info.guard_bonus > 0.0:
			caster_hp.add_guard(info.guard_bonus, clampf(recovery_time(cast), GUARD_MIN_SECONDS, GUARD_MAX_SECONDS))


func _apply_on_hit_stats(cast: SkillCast) -> void:
	var caster := cast.caster
	var life_on_hit := cast.stats.get_stat(StatTypes.Stat.LIFE_ON_HIT)
	if life_on_hit > 0.0:
		var caster_health := caster.get("health") as HealthComponent
		if caster_health != null:
			caster_health.heal(life_on_hit)

	var mana_on_hit := cast.stats.get_stat(StatTypes.Stat.MANA_ON_HIT)
	if mana_on_hit > 0.0:
		var caster_mana := caster.get("mana") as ManaComponent
		if caster_mana != null:
			caster_mana.gain_on_hit(mana_on_hit)
